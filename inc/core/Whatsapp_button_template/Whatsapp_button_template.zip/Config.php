<?php return array (
  'id' => 'whatsapp_button_template',
  'folder' => 'core',
  'name' => 'Button template',
  'author' => 'Stackcode',
  'author_uri' => 'sp',
  'desc' => 'Create interactive button messages',
  'icon' => 'fad fa-pager',
  'color' => '#d90058',
  'parent' => 
  array (
    'id' => 'template',
    'name' => 'template',
  ),
);